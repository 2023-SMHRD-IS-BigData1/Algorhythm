package com.smhrd.algo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgoApplicationTests {

	@Test
	void contextLoads() {
	}

}
